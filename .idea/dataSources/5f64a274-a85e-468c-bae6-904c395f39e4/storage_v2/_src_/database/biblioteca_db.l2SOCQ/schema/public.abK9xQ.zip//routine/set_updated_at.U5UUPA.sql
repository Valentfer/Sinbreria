create function set_updated_at() returns trigger
    language plpgsql
as
$$
BEGIN
    NEW.actualizado_en = NOW();
    RETURN NEW;
END;
$$;

alter function set_updated_at() owner to postgres;

